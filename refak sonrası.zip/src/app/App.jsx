import React, { useState, useEffect, lazy, Suspense, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from 'framer-motion';

// --- DATA (VERİ TABANLARI) ---
import { PHASES, BADGES, BADGE_ICONS, EXERCISE_DB, WORKOUT_PRESETS } from '@/features/fitness/workout/data/workoutData.js';
import { FOODS, MEAL_TEMPLATES, MEAL_TYPE_LABELS, DAY_NAMES, MEAL_RATIOS_BY_COUNT } from '@/features/fitness/nutrition/data/nutritionData.js';

// --- HOOKS & TIMERS ---
import { playDing, playFinish, useTimer, useRestTimer } from "@/features/fitness/workout/hooks/useWorkoutTimer.js";

// --- APP CORE & STATE ---
import { useAppStore } from '@/app/store.js';
import { THEMES } from '@/shared/ui/theme.js';
import { HapticEngine, SoundEngine } from '@/shared/lib/hapticSoundEngine.js';
import { useTranslation } from '@/shared/hooks/useTranslation.js';

// --- FIREBASE AUTH ---
import { auth } from '@/shared/lib/firebase.js';
import { onAuthStateChanged, signOut } from 'firebase/auth';

// --- COMPONENTS & SCREENS ---
import AuthScreen from '@/features/user/auth/components/AuthScreen.jsx';
import OnboardingWizard from '@/features/user/onboarding/components/OnboardingWizard.jsx';

// --- UTILS (MANTIK DOSYALARI) ---
import { generatePersonalizedPlan } from "@/features/user/onboarding/utils/generatorEngine.js";
import { generateMealPlan } from "@/features/fitness/nutrition/utils/nutritionUtils.js";
// Not: buildShoppingList genelde shared/lib veya nutritionUtils içindedir.
import { buildShoppingList } from "@/shared/lib/buildShoppingList.js"; 

// --- LAZY LOAD EDİLEN ÖZELLİKLER (FEATURES) ---
const TabNutrition = lazy(() => import('@/features/fitness/nutrition/components/TabNutrition.jsx'));
const TabProgram = lazy(() => import('@/features/fitness/workout/components/TabProgram.jsx'));
const TabToday = lazy(() => import('@/features/fitness/workout/components/TabToday.jsx'));
const TabProgress = lazy(() => import("@/features/fitness/progress/components/TabProgress.jsx"));
const TabProfile = lazy(() => import('@/features/user/profile/components/TabProfile.jsx'));
const TabSocial = lazy(() => import('@/features/social/components/TabSocial.jsx'));


// --- SABİTLER ---
const fonts = {
  header: "'Comucan', system-ui, sans-serif",
  body: "'Comucan', system-ui, sans-serif",
  mono: "monospace"
};

const TABS = [
  { id: 0, label: "Antrenman", icon: "🏋️‍♂️" },
  { id: 1, label: "Beslenme", icon: "🥗" },
  { id: 2, label: "İlerleme", icon: "📈" },
  { id: 3, label: "Topluluk", icon: "👥" },
  { id: 4, label: "Profilim", icon: "👤" }
];

const LoadingFallback = ({ C }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
    <motion.div 
      animate={{ rotate: 360 }} 
      transition={{ repeat: Infinity, duration: 1, ease: "linear" }} 
      style={{ width: 40, height: 40, borderRadius: "50%", border: `4px solid ${C?.border || '#333'}`, borderTopColor: C?.green || '#2ecc71', marginBottom: 16 }} 
    />
  </div>
);

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  
  // Timers
  const timer = useTimer(); 
  const restT = useRestTimer(); // ⚠️ Daha önce eksikti, eklendi!

  // Zustand Store
  const {
    screen, setScreen, user, setUser, macros, setMacros, activeThemeId, setActiveThemeId,
    completedW, setCW, weightLog, setWL, streak, setStreak, lastDate, setLastDate,
    badges, setBadges, customWorkouts, setCustomWorkouts, exNotesLog, setExNotesLog,
    mealPlan, setMealPlan, setCustomTargetMacros, sessionSets, setSessionSets,
    incrementStreak
  } = useAppStore();

  // i18n
  const { t, changeLanguage, currentLanguage } = useTranslation();

  // Local State
  const [tab, setTab] = useState(0);
  const [activePhase, setActivePhase] = useState(0);
  const [activeDay, setActiveDay] = useState(0);
  const [nutDay, setNutDay] = useState(0);
  const [sessActive, setSessActive] = useState(false);
  const [sessPhase, setSessPhase] = useState(0);
  const [sessDay, setSessDay] = useState(0);
  const [toast, setToast] = useState(null);
  
  const C = THEMES[activeThemeId] || THEMES.midnight;

   // Firebase Auth Listener
   useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (authUser) => {
      setCurrentUser(authUser);
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
   }, []);

   const handleLogout = async () => {
    try {
      await signOut(auth);
      HapticEngine.medium();
    } catch (err) {
      console.error("Çıkış hatası:", err);
    }
   };

   const showToast = (icon, text) => {
    setToast({ icon, text });
    setTimeout(() => setToast(null), 3000);
   };

   // handleWizardComplete fonksiyonunu bu şekilde güncelle:
const handleWizardComplete = (formData, skipWorkoutGen = false) => {
  localStorage.clear(); // Tüm tarayıcı hafızasını zorla temizle
window.location.reload(); // Sayfayı temiz bir başlangıç için yeniden yükle
  try {
    // 1. Önce her şeyi sıfırla (Eski profilden eser kalmasın)
    const resetAllData = useAppStore.getState().resetAllWorkoutData; 
    if (resetAllData) resetAllData(); 
    // Not: Eğer store'unda global bir reset yoksa consumedFoods: [], streak: 0 vb. manuel setle.

    const generatedData = generatePersonalizedPlan(formData);

    if (setCustomTargetMacros) setCustomTargetMacros(generatedData.macros);
    setMacros(generatedData.macros);

    if (skipWorkoutGen) {
      setCustomWorkouts([]);
      setUser({ ...user, ...formData, hasCompletedOnboarding: true, activePlanName: "Özel Rutinim" });
    } else {
      // İlerleme sekmesi için standart format
      const formattedPlan = {
          id: `plan_${Date.now()}`,
          name: generatedData.planName || "Kişisel Protokol",
          workouts: generatedData.workouts
      };
      setCustomWorkouts([formattedPlan]); 
      setUser({ ...user, ...formData, hasCompletedOnboarding: true, activePlanName: generatedData.planName });
    }
    setStep('main');
  } catch (err) {
    console.error("Wizard Error:", err);
  }
};

   const regeneratePlan = () => {
    if (!macros || !user) return;
    setMealPlan(generateMealPlan(macros, user));
    // t('msg_saved') fonksiyonu undefined dönerse fallback olarak Türkçe veriyoruz
    showToast("🔄", t('msg_saved') || "Plan Güncellendi");   
   };

   // 2. checkBadges fonksiyonunu güncelle:
   const checkBadges = useCallback((cw, str) => {
    BADGES.forEach(b => {
      if (!badges.includes(b.id) && b.check(cw, str)) {
        setBadges(p => [...p, b.id]); // setBD -> setBadges oldu
        showToast(BADGE_ICONS[b.icon] || "🏅", `Rozet: ${b.label}`);
      }
    });
   }, [badges, setBadges]);

    const finishSession = (sessionData = {}) => {
    const key = `${sessPhase}-${sessDay}`;
    
    incrementStreak();

    if (sessionData.notes) {
      setExNotesLog(prev => ({ ...prev, ...sessionData.notes }));
    }

    setCW(prev => {
      const next = { ...prev, [key]: true };
      setTimeout(() => checkBadges(next, streak + 1), 0);
      return next;
    });

    setSessActive(false);
    timer.reset();
    restT.stop();
    
    const setActiveWorkoutSession = useAppStore.getState().setActiveWorkoutSession;
    if (setActiveWorkoutSession) setActiveWorkoutSession(null);
    localStorage.removeItem('activeWorkoutSession'); // 🔥 GARANTİ TEMİZLİK

    SoundEngine.success();

    SoundEngine.success();
    HapticEngine.success();
    showToast("🎉", "Antrenman başarıyla kaydedildi!");
  };

  // ⚠️ İstatistik Hesaplamaları (Daha önce eksikti, eklendi)
  const total = customWorkouts?.length || 0;
  const totalDone = Object.values(completedW || {}).filter(Boolean).length;
  const overallPct = total > 0 ? Math.round((totalDone / total) * 100) : 0;

  // Memoized Veriler
  const activePlan = useMemo(() => 
    mealPlan || (macros ? generateMealPlan(macros, user || {}) : null), 
    [mealPlan, macros, user]
  );

  const dayPlan = useMemo(() => activePlan ? activePlan[nutDay] : null, [activePlan, nutDay]);
  
  const shopping = useMemo(() => 
    buildShoppingList ? buildShoppingList(activePlan) : [],
    [activePlan]
  );

  // Render: Yükleniyor Ekranı
  if (isAuthLoading) {
    return (
      <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }} style={{ fontSize: 40, marginBottom: 20 }}>⚡</motion.div>
        <div style={{ color: C.text, fontSize: 12, fontWeight: 900, letterSpacing: 4, fontFamily: fonts.mono }}>MOTORLAR ISINIYOR...</div>
      </div>
    );
  }

  // Render: Kimlik Doğrulama ve Sihirbaz
  if (!currentUser) return <AuthScreen C={C} />;
  if (!user?.hasCompletedOnboarding) return <OnboardingWizard onComplete={handleWizardComplete} themeColors={C} />;

  // Render: Ana Uygulama
  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: fonts.body }}>
      
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50, x: "-50%" }} 
            animate={{ opacity: 1, y: 0, x: "-50%" }} 
            exit={{ opacity: 0, y: -50, x: "-50%" }}
            style={{ 
              position: "fixed", top: 24, left: "50%", background: C.card, 
              border: `1px solid ${C.green}`, padding: "14px 24px", borderRadius: 20, 
              zIndex: 10000, display: "flex", alignItems: "center", gap: 12 
            }}
          >
            <span style={{ fontSize: 24 }}>{toast.icon}</span>
            <span style={{ fontSize: 15, color: C.text, fontWeight: 800, fontFamily: fonts.header }}>{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div style={{ maxWidth: 768, margin: "0 auto", position: "relative" }}>
        
        {/* Header */}
        <div style={{ padding: "24px 24px", background: C.card, borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 24, fontWeight: 900, fontFamily: fonts.header, fontStyle: "italic", color: C.text }}>
              Protocol <span style={{color: C.green}}>✓</span>
            </h1>
            <div style={{ fontSize: 11, color: C.green, fontWeight: 800, marginTop: 4 }}>
              {user?.activePlanName ? user.activePlanName.toUpperCase() : "AKTİF PROTOKOL"}
            </div>
          </div>
          <button 
            onClick={handleLogout}
            style={{ background: 'rgba(255,255,255,0.05)', border: `1px solid ${C.border}`, color: C.mute, padding: '8px 12px', borderRadius: 10, fontSize: 10, fontWeight: 800, cursor: 'pointer' }}
          >
            Çıkış Yap
          </button>
        </div>

        {/* İçerik Alanı */}
        <div style={{ padding: "24px 20px", paddingBottom: 110 }}>
          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }}>
              <Suspense fallback={<LoadingFallback C={C} />}>
                
                {tab === 0 && (
                  <TabToday 
                    sessActive={sessActive} 
                    setSessActive={setSessActive}
                    activePhase={activePhase} 
                    setActivePhase={setActivePhase}
                    activeDay={activeDay} 
                    setActiveDay={setActiveDay}
                    sessPhase={sessPhase} 
                    setSessPhase={setSessPhase}
                    sessDay={sessDay} 
                    setSessDay={setSessDay}
                    timer={timer} 
                    restT={restT} 
                    weightLog={weightLog} 
                    setWL={setWL}
                    completedW={completedW} 
                    finishSession={finishSession}
                    PHASES={PHASES} 
                    themeColors={C} 
                    playDing={playDing}
                    sessionSets={sessionSets} 
                    setSessionSets={setSessionSets}
                    customWorkouts={customWorkouts} 
                    setCustomWorkouts={setCustomWorkouts} 
                    EXERCISE_DB={EXERCISE_DB}
                    exNotesLog={exNotesLog} 
                    showToast={showToast}
                  />
                )}

                {tab === 1 && (
                  <TabNutrition 
                    user={user} 
                    macros={macros} 
                    regeneratePlan={regeneratePlan}
                    dayPlan={dayPlan} 
                    nutDay={nutDay} 
                    setNutDay={setNutDay}
                    themeColors={C} 
                    shoppingList={shopping} 
                  />
                )}

                {tab === 2 && (
                  <TabProgress 
                    totalDone={totalDone} 
                    overallPct={overallPct} 
                    badges={badges} 
                    BADGES={BADGES} 
                    BADGE_ICONS={BADGE_ICONS}
                    weightLog={weightLog} 
                    themeColors={C} 
                    hasActiveProgram={customWorkouts?.length > 0}
                    selectedProgram={customWorkouts?.length > 0 ? { name: "Mevcut Rutinim", workouts: customWorkouts } : null}
                    onSelectProgram={() => setTab(0)} 
                  />
                )}

                {tab === 3 && <TabSocial themeColors={C} />}
                {tab === 4 && <TabProfile themeColors={C} />} 

              </Suspense>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Alt Navigasyon */}
        <div style={{ 
          position: 'fixed', 
          bottom: 0, 
          left: '50%', 
          transform: 'translateX(-50%)', 
          width: '100%', 
          maxWidth: 768, 
          background: `${C.card}e6`, 
          backdropFilter: 'blur(16px)', 
          borderTop: `1px solid ${C.border}`, 
          borderTopLeftRadius: 28, 
          borderTopRightRadius: 28, 
          display: 'flex', 
          padding: '12px 12px 24px 12px', 
          paddingBottom: `calc(24px + env(safe-area-inset-bottom, 12px))`, 
          zIndex: 1000 
        }}>
          {TABS.map(t => {
            const isActive = tab === t.id;
            return (
              <motion.button 
                key={t.id} 
                onClick={() => { setTab(t.id); HapticEngine.light(); SoundEngine.tick(); }} 
                whileTap={{ scale: 0.92 }} 
                style={{ 
                  flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', 
                  background: isActive ? `${C.green}15` : 'transparent', border: 'none', 
                  borderRadius: 20, cursor: 'pointer', padding: '12px 0' 
                }}
              >
                <div style={{ fontSize: 24, color: isActive ? C.green : C.mute }}>{t.icon}</div>
                <div style={{ fontSize: 11, color: isActive ? C.green : C.sub, fontWeight: isActive ? 900 : 600, fontFamily: fonts.header }}>
                  {t.label}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}