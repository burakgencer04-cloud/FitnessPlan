// vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  base: './',
  plugins: [
    react(),
    // VitePWA eklenecekse buraya aç: VitePWA({...})
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    }
  },
  
  // 🔥 TEST YAPILANDIRMASI BURAYA TAŞINDI (Unified Config)
  test: {
    globals: true,
    environment: 'jsdom',
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      exclude: ['node_modules/', 'src/test/', '**/*.config.js'],
      thresholds: { lines: 80, functions: 80, branches: 80, statements: 80 }
    }
  },

  // 🔥 PRODUCTION GÜVENLİĞİ (Logları temizler)
  esbuild: {
    pure: ['console.log', 'console.info'],
    drop: ['debugger'],
  },
  
  build: {
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('react') || id.includes('react-dom')) return 'vendor';
            if (id.includes('recharts')) return 'charts';
            if (id.includes('framer-motion')) return 'animations';
            if (id.includes('zustand')) return 'store';
          }
        }
      }
    }
  }
})