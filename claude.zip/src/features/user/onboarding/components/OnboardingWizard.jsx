import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next'; 

import { THEMES } from '@/shared/ui/theme';
import { generatePersonalizedPlan } from "@/features/user/onboarding/utils/generatorEngine.js";
import { WORKOUT_PRESETS } from '@/features/fitness/workout/data/workoutData.js';

// 🔥 HOOK IMPORT EKLENDİ
import { useModalStore } from '@/app/useModalStore.js';

const fonts = {
  header: "'Comucan', system-ui, sans-serif",
  body: "'Comucan', system-ui, sans-serif",
  mono: "monospace"
};

const POPULAR_DISLIKES = ["Mantar", "Brokoli", "Sakatat", "Balık", "Deniz Ürünleri", "Patlıcan", "Süt", "Yumurta", "Kuzu Eti", "Kereviz", "Pırasa", "Zeytin", "Kavun"];
const POPULAR_LIKES = ["Tavuk", "Kırmızı Et", "Yumurta", "Yulaf", "Fıstık Ezmesi", "Avokado", "Peynir", "Kahve", "Pirinç", "Patates", "Muz", "Yoğurt", "Makarna"];

const ExpandableDietCard = ({ diet, isSelected, onClick, color, C, t }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div 
      style={{
        background: isSelected ? `linear-gradient(145deg, ${color}20, transparent)` : `rgba(0,0,0,0.2)`,
        border: `1px solid ${isSelected ? color : `${C.border}40`}`,
        borderRadius: 20, overflow: "hidden", display: "flex", flexDirection: "column",
        boxShadow: isSelected ? `0 10px 30px ${color}20` : "none", transition: "all 0.3s ease",
        backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)", marginBottom: 12
      }}
    >
      <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", gap: 16, cursor: "pointer" }} onClick={onClick}>
        <div style={{ fontSize: 32, filter: isSelected ? `drop-shadow(0 0 10px ${color}80)` : "grayscale(100%) opacity(50%)", transition: "0.3s" }}>{diet.icon}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 900, color: isSelected ? color : C.text, fontFamily: fonts.header, marginBottom: 4 }}>{diet.title}</div>
          <div style={{ fontSize: 12, color: C.mute, lineHeight: 1.4 }}>{diet.shortDesc}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          <div style={{ width: 24, height: 24, borderRadius: "50%", border: `2px solid ${isSelected ? color : C.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            {isSelected && <div style={{ width: 12, height: 12, borderRadius: "50%", background: color }} />}
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); setIsExpanded(!isExpanded); }} 
            style={{ background: "transparent", border: "none", color: C.sub, fontSize: 10, cursor: "pointer", textDecoration: "underline", padding: 4 }}
          >
            {isExpanded ? t('wiz_btn_hide') : t('wiz_btn_details')}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} style={{ overflow: "hidden" }}>
            <div style={{ padding: "0 20px 20px 20px", fontSize: 12, lineHeight: 1.5, color: C.mute }}>
              <div style={{ borderTop: `1px dashed ${C.border}40`, paddingTop: 12, marginTop: 4 }}>
                <p style={{ margin: "0 0 8px 0" }}><strong style={{ color: C.text }}>{t('wiz_diet_macro')}:</strong> {diet.macros}</p>
                <p style={{ margin: "0 0 8px 0" }}><strong style={{ color: C.text }}>{t('wiz_diet_principle')}:</strong> {diet.principle}</p>
                <p style={{ margin: "0 0 8px 0" }}><strong style={{ color: C.text }}>{t('wiz_diet_benefits')}:</strong> {diet.benefits}</p>
                <p style={{ margin: "0 0 8px 0" }}><strong style={{ color: C.text }}>{t('wiz_diet_risks')}:</strong> {diet.risks}</p>
                <p style={{ margin: 0 }}><strong style={{ color: C.green }}>{t('wiz_diet_audience')}:</strong> {diet.targetAudience}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const SelectionCard = ({ title, desc, icon, isSelected, onClick, color, C }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={onClick}
    style={{
      background: isSelected ? `linear-gradient(145deg, ${color}20, transparent)` : `rgba(0,0,0,0.2)`,
      border: `1px solid ${isSelected ? color : `${C.border}40`}`,
      padding: "16px 20px", borderRadius: 20, cursor: "pointer", display: "flex", alignItems: "center", gap: 16,
      boxShadow: isSelected ? `0 10px 30px ${color}20` : "none", transition: "all 0.3s ease",
      backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)"
    }}
  >
    <div style={{ fontSize: 32, filter: isSelected ? `drop-shadow(0 0 10px ${color}80)` : "grayscale(100%) opacity(50%)", transition: "0.3s" }}>{icon}</div>
    <div>
      <div style={{ fontSize: 16, fontWeight: 900, color: isSelected ? color : C.text, fontFamily: fonts.header, marginBottom: 4 }}>{title}</div>
      <div style={{ fontSize: 12, color: C.mute, lineHeight: 1.4 }}>{desc}</div>
    </div>
    <div style={{ marginLeft: "auto", width: 24, height: 24, borderRadius: "50%", border: `2px solid ${isSelected ? color : C.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
      {isSelected && <div style={{ width: 12, height: 12, borderRadius: "50%", background: color }} />}
    </div>
  </motion.div>
);

export default function OnboardingWizard({ onComplete, themeColors: C }) {
  const { t } = useTranslation(); 
  const { openModal } = useModalStore(); // 🔥 MODAL ÇAĞIRICI EKLENDİ
  const [step, setStep] = useState(1);
  const totalSteps = 8; 

  const [isCalculating, setIsCalculating] = useState(false);
  const [calcText, setCalcText] = useState(t('wiz_load_0') || "Veriler işleniyor...");

  const [form, setForm] = useState({
    firstName: "", lastName: "", city: "", 
    gender: "", dobDay: "", dobMonth: "", dobYear: "",
    unitWeight: "kg", unitLength: "cm",
    height: "", startWeight: "", targetWeight: "",
    goal: "", activity: "",
    dietType: "",
    experience: "", days: null,
    likes: [], dislikes: [],
    waterGoalLiters: "" 
  });

  const DIET_OPTIONS = [
    { id: "standart", color: C.blue, icon: "🍽️", title: t('diet_std_title'), shortDesc: t('diet_std_desc'), macros: t('diet_std_mac'), principle: t('diet_std_prin'), benefits: t('diet_std_ben'), risks: t('diet_std_risk'), targetAudience: t('diet_std_aud') },
    { id: "high_protein", color: C.text, icon: "🥩", title: t('diet_pro_title'), shortDesc: t('diet_pro_desc'), macros: t('diet_pro_mac'), principle: t('diet_pro_prin'), benefits: t('diet_pro_ben'), risks: t('diet_pro_risk'), targetAudience: t('diet_pro_aud') },
    { id: "akdeniz", color: C.yellow, icon: "🫒", title: t('diet_med_title'), shortDesc: t('diet_med_desc'), macros: t('diet_med_mac'), principle: t('diet_med_prin'), benefits: t('diet_med_ben'), risks: t('diet_med_risk'), targetAudience: t('diet_med_aud') },
    { id: "keto", color: C.red, icon: "🥑", title: t('diet_keto_title'), shortDesc: t('diet_keto_desc'), macros: t('diet_keto_mac'), principle: t('diet_keto_prin'), benefits: t('diet_keto_ben'), risks: t('diet_keto_risk'), targetAudience: t('diet_keto_aud') },
    { id: "if", color: C.mute, icon: "⏱️", title: t('diet_if_title'), shortDesc: t('diet_if_desc'), macros: t('diet_if_mac'), principle: t('diet_if_prin'), benefits: t('diet_if_ben'), risks: t('diet_if_risk'), targetAudience: t('diet_if_aud') },
    { id: "dash", color: C.blue, icon: "🩸", title: t('diet_dash_title'), shortDesc: t('diet_dash_desc'), macros: t('diet_dash_mac'), principle: t('diet_dash_prin'), benefits: t('diet_dash_ben'), risks: t('diet_dash_risk'), targetAudience: t('diet_dash_aud') },
    { id: "flexitarian", color: C.green, icon: "🥗", title: t('diet_flex_title'), shortDesc: t('diet_flex_desc'), macros: t('diet_flex_mac'), principle: t('diet_flex_prin'), benefits: t('diet_flex_ben'), risks: t('diet_flex_risk'), targetAudience: t('diet_flex_aud') },
    { id: "vegan", color: C.green, icon: "🌱", title: t('diet_vegan_title'), shortDesc: t('diet_vegan_desc'), macros: t('diet_vegan_mac'), principle: t('diet_vegan_prin'), benefits: t('diet_vegan_ben'), risks: t('diet_vegan_risk'), targetAudience: t('diet_vegan_aud') }
  ];

  // 🔥 7 ADET ALERT, ASENKRON MODAL İLE DEĞİŞTİRİLDİ
  const handleNext = () => {
    if (step === 1 && (!form.firstName.trim() || !form.lastName.trim() || !form.city.trim())) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_personal') || "Tüm kişisel bilgileri doldurun." });
    if (step === 2 && (!form.gender || !form.dobDay || !form.dobMonth || !form.dobYear)) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_demographics') || "Cinsiyet ve doğum tarihini seçin." });
    if (step === 3 && (!form.height || !form.startWeight || !form.targetWeight)) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_body') || "Tüm vücut ölçülerini girin." });
    if (step === 4 && (!form.goal || !form.activity)) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_goal') || "Hedefinizi ve aktivite seviyenizi seçin." });
    if (step === 5 && !form.dietType) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_diet') || "Bir beslenme tarzı seçin." });
    if (step === 6 && (!form.experience || !form.days)) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_workout') || "Spor geçmişi ve gün sayısını seçin." });
    if (step === 8 && !form.waterGoalLiters) return openModal({ type: 'alert', title: 'Eksik Bilgi', message: t('wiz_err_water') || "Su hedefini girin." });

    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      startFakeCalculation();
    }
  };

  const toggleArrayItem = (field, item) => {
    setForm(prev => {
      const arr = prev[field] || [];
      if (arr.includes(item)) return { ...prev, [field]: arr.filter(i => i !== item) };
      return { ...prev, [field]: [...arr, item] };
    });
  };

  const startFakeCalculation = () => {
    setIsCalculating(true);
    const loadingTexts = [
      t('wiz_load_1') || "Makrolar hesaplanıyor...",
      t('wiz_load_2') || "Antrenman programı yazılıyor...",
      t('wiz_load_3') || "Diyet planı oluşturuluyor...",
      t('wiz_load_4') || "Son kontroller yapılıyor...",
      t('wiz_load_5') || "Hazır!",
    ];
    let index = 0;
    const interval = setInterval(() => {
      if (index < loadingTexts.length - 1) {
        index++;
        setCalcText(loadingTexts[index]);
      }
    }, 1500);

    setTimeout(() => { clearInterval(interval); finalizeSetup(); }, 7500);
  };

 const finalizeSetup = () => {
    const age = new Date().getFullYear() - parseInt(form.dobYear || "2000");
    const dobString = `${form.dobYear}-${form.dobMonth.padStart(2, '0')}-${form.dobDay.padStart(2, '0')}`;
    
    const standardizedGender = form.gender === "erkek" ? "male" : "female";
    
    let standardizedGoal = "maintain";
    if (form.goal === "kilo_ver") standardizedGoal = "cut";
    else if (form.goal === "kilo_al") standardizedGoal = "bulk";

    const targetDays = parseInt(form.days) || 3;
    const exp = form.experience || "baslangic"; 
    let targetId = "fb_3";
    
    if (targetDays <= 2) targetId = "fb_2";
    else if (targetDays === 3) targetId = (exp === "baslangic") ? "fb_3" : "ppl_3";
    else if (targetDays === 4) targetId = "ul_4";
    else if (targetDays === 5) targetId = "pplul_5";
    else if (targetDays >= 6) targetId = "ppl_6";

    let matchedPlan = WORKOUT_PRESETS.find(p => p.id === targetId);
    if (!matchedPlan) matchedPlan = WORKOUT_PRESETS.find(p => p.workouts && p.workouts.length === targetDays);
    if (!matchedPlan) matchedPlan = WORKOUT_PRESETS[WORKOUT_PRESETS.length - 1] || WORKOUT_PRESETS[0];

    const finalWorkouts = matchedPlan?.workouts || (matchedPlan?.phases && matchedPlan.phases[0]?.workouts) || [];

    const finalData = {
      ...form, 
      dob: dobString, 
      age: age > 10 ? age : 25, 
      weight: parseFloat(form.startWeight), 
      gender: standardizedGender,
      goal: standardizedGoal,
      weeklyGoal: form.goal === "koru" ? "0" : "0.5", 
      stepGoal: form.activity === "sedanter" ? 6000 : (form.activity === "aktif" ? 12000 : 10000),
      waterUnit: "ml",
      waterGoal: parseFloat(form.waterGoalLiters || 2.5) * 1000, 
      
      activePlanId: matchedPlan.id,
      activePlanName: matchedPlan.name,
      customWorkouts: finalWorkouts 
    };

    onComplete(finalData);
  };

  const inputStyle = { 
    width: "100%", background: "rgba(0,0,0,0.3)", border: `1px solid ${C.border}60`, color: C.text, 
    padding: "16px 20px", borderRadius: 20, outline: "none", fontFamily: fonts.mono, fontSize: 16, 
    marginBottom: 16, transition: "0.3s", textAlign: "center" 
  };

  const labelStyle = { 
    display: "block", fontSize: 11, color: C.sub, fontWeight: 800, 
    letterSpacing: 2, marginBottom: 8, textAlign: "center", textTransform: "uppercase" 
  };

  if (isCalculating) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: C.text, fontFamily: fonts.body, position: "relative" }}>
        <div style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }}>
          <motion.div animate={{ opacity: [0.2, 0.4, 0.2] }} transition={{ duration: 4, repeat: Infinity }} style={{ position: 'absolute', top: '50%', left: '50%', transform: "translate(-50%, -50%)", width: '80vw', height: '80vw', background: `radial-gradient(circle, ${C.green}30 0%, transparent 60%)`, filter: 'blur(80px)' }} />
        </div>
        <div style={{ position: "relative", zIndex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }} style={{ width: 72, height: 72, borderRadius: "50%", border: `4px solid ${C.border}40`, borderTopColor: C.green, marginBottom: 32, boxShadow: `0 0 30px ${C.green}40` }} />
          <AnimatePresence mode="wait">
            <motion.h2 key={calcText} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }} transition={{ duration: 0.4 }} style={{ margin: 0, fontSize: 20, fontWeight: 900, fontFamily: fonts.header, textAlign: "center", color: C.text, letterSpacing: 0.5, padding: "0 20px" }}>
              {calcText}
            </motion.h2>
          </AnimatePresence>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: "100%", overflowY: "auto", background: C.bg, display: "flex", flexDirection: "column", color: C.text, fontFamily: fonts.body }}>
      <div style={{ position: 'absolute', inset: 0, zIndex: 0, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', top: '-10%', left: '-10%', width: '70vw', height: '70vw', background: `radial-gradient(circle, ${C.blue}20 0%, transparent 60%)`, filter: 'blur(80px)' }} />
        <div style={{ position: 'absolute', bottom: '-10%', right: '-10%', width: '70vw', height: '70vw', background: `radial-gradient(circle, ${C.green}1A 0%, transparent 60%)`, filter: 'blur(80px)' }} />
      </div>

      <div style={{ position: "relative", zIndex: 1, flex: 1, display: "flex", flexDirection: "column", width: "100%", padding: "40px 20px" }}>
        
        <div style={{ display: "flex", gap: 6, marginBottom: 40 }}>
          {[...Array(totalSteps)].map((_, i) => (
            <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i + 1 <= step ? C.green : `rgba(255,255,255,0.1)`, transition: "0.3s" }} />
          ))}
        </div>

        <AnimatePresence mode="wait">
          
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>👋</div>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step1_title')}</h2>
              <p style={{ margin: "0 0 32px 0", fontSize: 15, color: C.sub, lineHeight: 1.5 }}>{t('wiz_step1_desc')}</p>
              
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                <div>
                  <label style={labelStyle}>{t('wiz_lbl_name')}</label>
                  <input type="text" placeholder={t('wiz_ph_name')} value={form.firstName} onChange={e => setForm({...form, firstName: e.target.value})} style={{ ...inputStyle, marginBottom: 0 }} />
                </div>
                <div>
                  <label style={labelStyle}>{t('wiz_lbl_surname')}</label>
                  <input type="text" placeholder={t('wiz_ph_surname')} value={form.lastName} onChange={e => setForm({...form, lastName: e.target.value})} style={{ ...inputStyle, marginBottom: 0 }} />
                </div>
              </div>
              <label style={{...labelStyle, marginTop: 16}}>{t('wiz_lbl_city')}</label>
              <input type="text" placeholder={t('wiz_ph_city')} value={form.city} onChange={e => setForm({...form, city: e.target.value})} style={inputStyle} />
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step2_title')}</h2>
              <p style={{ margin: "0 0 32px 0", fontSize: 15, color: C.sub }}>{t('wiz_step2_desc')}</p>
              
              <label style={labelStyle}>{t('wiz_lbl_gender')}</label>
              <div style={{ display: "flex", gap: 16, marginBottom: 32 }}>
                <button onClick={() => setForm({...form, gender: "erkek"})} style={{ flex: 1, background: form.gender === "erkek" ? `linear-gradient(145deg, ${C.blue}30, transparent)` : "rgba(0,0,0,0.3)", border: `1px solid ${form.gender === "erkek" ? C.blue : `${C.border}40`}`, color: form.gender === "erkek" ? C.text : C.mute, padding: "20px", borderRadius: 20, fontSize: 16, fontWeight: 900, cursor: "pointer", backdropFilter: "blur(12px)" }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>👨</div> {t('wiz_gender_male')}
                </button>
                <button onClick={() => setForm({...form, gender: "kadin"})} style={{ flex: 1, background: form.gender === "kadin" ? `linear-gradient(145deg, ${C.red}30, transparent)` : "rgba(0,0,0,0.3)", border: `1px solid ${form.gender === "kadin" ? C.red : `${C.border}40`}`, color: form.gender === "kadin" ? C.text : C.mute, padding: "20px", borderRadius: 20, fontSize: 16, fontWeight: 900, cursor: "pointer", backdropFilter: "blur(12px)" }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>👩</div> {t('wiz_gender_female')}
                </button>
              </div>

              <label style={labelStyle}>{t('wiz_lbl_dob')}</label>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, background: "rgba(255,255,255,0.02)", padding: 16, borderRadius: 24, border: `1px solid ${C.border}30` }}>
                <input type="number" placeholder={t('wiz_ph_day')} value={form.dobDay} onChange={e => setForm({...form, dobDay: e.target.value})} style={{ ...inputStyle, marginBottom: 0 }} />
                <input type="number" placeholder={t('wiz_ph_month')} value={form.dobMonth} onChange={e => setForm({...form, dobMonth: e.target.value})} style={{ ...inputStyle, marginBottom: 0 }} />
                <input type="number" placeholder={t('wiz_ph_year')} value={form.dobYear} onChange={e => setForm({...form, dobYear: e.target.value})} style={{ ...inputStyle, marginBottom: 0 }} />
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step3_title')}</h2>
              <p style={{ margin: "0 0 24px 0", fontSize: 15, color: C.sub }}>{t('wiz_step3_desc')}</p>
              
              <div style={{ display: "flex", justifyContent: "center", gap: 16, marginBottom: 24 }}>
                <div style={{ display: "flex", background: "rgba(0,0,0,0.3)", borderRadius: 12, padding: 4 }}>
                  <button onClick={() => setForm({...form, unitWeight: "kg"})} style={{ border: "none", padding: "6px 12px", borderRadius: 8, background: form.unitWeight === "kg" ? C.text : "transparent", color: form.unitWeight === "kg" ? C.bg : C.mute, fontWeight: 900, cursor: "pointer", fontSize: 12 }}>KG</button>
                  <button onClick={() => setForm({...form, unitWeight: "lb"})} style={{ border: "none", padding: "6px 12px", borderRadius: 8, background: form.unitWeight === "lb" ? C.text : "transparent", color: form.unitWeight === "lb" ? C.bg : C.mute, fontWeight: 900, cursor: "pointer", fontSize: 12 }}>LB</button>
                </div>
                <div style={{ display: "flex", background: "rgba(0,0,0,0.3)", borderRadius: 12, padding: 4 }}>
                  <button onClick={() => setForm({...form, unitLength: "cm"})} style={{ border: "none", padding: "6px 12px", borderRadius: 8, background: form.unitLength === "cm" ? C.text : "transparent", color: form.unitLength === "cm" ? C.bg : C.mute, fontWeight: 900, cursor: "pointer", fontSize: 12 }}>CM</button>
                  <button onClick={() => setForm({...form, unitLength: "ft"})} style={{ border: "none", padding: "6px 12px", borderRadius: 8, background: form.unitLength === "ft" ? C.text : "transparent", color: form.unitLength === "ft" ? C.bg : C.mute, fontWeight: 900, cursor: "pointer", fontSize: 12 }}>FT</button>
                </div>
              </div>

              <div style={{ background: `linear-gradient(145deg, rgba(255,255,255,0.05), rgba(0,0,0,0.2))`, padding: 24, borderRadius: 24, border: `1px solid ${C.border}40`, backdropFilter: "blur(12px)" }}>
                <label style={labelStyle}>{t('wiz_lbl_height')} ({form.unitLength.toUpperCase()})</label>
                <input type="number" placeholder={form.unitLength === "cm" ? "180" : "5.9"} value={form.height} onChange={e => setForm({...form, height: e.target.value})} style={inputStyle} />

                <label style={{...labelStyle, marginTop: 16}}>{t('wiz_lbl_current_w')} ({form.unitWeight.toUpperCase()})</label>
                <input type="number" placeholder={form.unitWeight === "kg" ? "80" : "176"} value={form.startWeight} onChange={e => setForm({...form, startWeight: e.target.value})} style={inputStyle} />

                <label style={{...labelStyle, marginTop: 16, color: C.green}}>{t('wiz_lbl_target_w')} ({form.unitWeight.toUpperCase()})</label>
                <input type="number" placeholder={form.unitWeight === "kg" ? "70" : "154"} value={form.targetWeight} onChange={e => setForm({...form, targetWeight: e.target.value})} style={{...inputStyle, borderColor: C.green, color: C.green}} />
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="step4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step4_title')}</h2>
              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 32 }}>
                <SelectionCard title={t('wiz_goal_lose')} desc={t('wiz_goal_lose_desc')} icon="🔥" isSelected={form.goal === "kilo_ver"} onClick={() => setForm({...form, goal: "kilo_ver"})} color={C.red} C={C} />
                <SelectionCard title={t('wiz_goal_gain')} desc={t('wiz_goal_gain_desc')} icon="🥩" isSelected={form.goal === "kilo_al"} onClick={() => setForm({...form, goal: "kilo_al"})} color={C.blue} C={C} />
                <SelectionCard title={t('wiz_goal_muscle')} desc={t('wiz_goal_muscle_desc')} icon="💪" isSelected={form.goal === "kas_yap"} onClick={() => setForm({...form, goal: "kas_yap"})} color={C.green} C={C} />
              </div>

              <h2 style={{ margin: "0 0 12px 0", fontSize: 20, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step4_subtitle')}</h2>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <SelectionCard title={t('wiz_act_sed')} desc={t('wiz_act_sed_desc')} icon="💻" isSelected={form.activity === "sedanter"} onClick={() => setForm({...form, activity: "sedanter"})} color={C.mute} C={C} />
                <SelectionCard title={t('wiz_act_mod')} desc={t('wiz_act_mod_desc')} icon="🚶‍♂️" isSelected={form.activity === "orta"} onClick={() => setForm({...form, activity: "orta"})} color={C.yellow} C={C} />
                <SelectionCard title={t('wiz_act_act')} desc={t('wiz_act_act_desc')} icon="⚡" isSelected={form.activity === "aktif"} onClick={() => setForm({...form, activity: "aktif"})} color={C.red} C={C} />
              </div>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div key="step5" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step5_title')}</h2>
              <p style={{ margin: "0 0 24px 0", fontSize: 15, color: C.sub }}>{t('wiz_step5_desc')}</p>
              
              <div style={{ display: "flex", flexDirection: "column" }}>
                {DIET_OPTIONS.map(diet => (
                  <ExpandableDietCard 
                    key={diet.id} 
                    diet={diet} 
                    C={C} 
                    t={t}
                    color={diet.color}
                    isSelected={form.dietType === diet.id}
                    onClick={() => setForm({...form, dietType: diet.id})}
                  />
                ))}
              </div>
            </motion.div>
          )}

          {step === 6 && (
            <motion.div key="step6" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step6_title')}</h2>
              <p style={{ margin: "0 0 32px 0", fontSize: 15, color: C.sub }}>{t('wiz_step6_desc')}</p>
              
              <label style={labelStyle}>{t('wiz_lbl_sport_hist')}</label>
              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 32 }}>
                <SelectionCard title={t('wiz_exp_beg')} desc={t('wiz_exp_beg_desc')} icon="👶" isSelected={form.experience === "beginner"} onClick={() => setForm({...form, experience: "beginner"})} color={C.green} C={C} />
                <SelectionCard title={t('wiz_exp_int')} desc={t('wiz_exp_int_desc')} icon="🧑‍🔧" isSelected={form.experience === "intermediate"} onClick={() => setForm({...form, experience: "intermediate"})} color={C.blue} C={C} />
                <SelectionCard title={t('wiz_exp_adv')} desc={t('wiz_exp_adv_desc')} icon="🦍" isSelected={form.experience === "advanced"} onClick={() => setForm({...form, experience: "advanced"})} color={C.red} C={C} />
              </div>

              <label style={labelStyle}>{t('wiz_lbl_train_days')}</label>
              <div style={{ display: "flex", gap: 12 }}>
                {[3, 4, 5].map(d => (
                  <button 
                    key={d} 
                    onClick={() => setForm({...form, days: d})}
                    style={{ flex: 1, background: form.days === d ? C.text : "rgba(0,0,0,0.3)", color: form.days === d ? C.bg : C.mute, border: `1px solid ${form.days === d ? C.text : `${C.border}40`}`, padding: "16px", borderRadius: 16, fontSize: 20, fontWeight: 900, cursor: "pointer", transition: "0.2s" }}
                  >
                    {d} {t('wiz_day')}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 7 && (
            <motion.div key="step7" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1 }}>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header }}>{t('wiz_step7_title')}</h2>
              <p style={{ margin: "0 0 32px 0", fontSize: 15, color: C.sub }}>
                {t('wiz_step7_desc')}
              </p>
              
              <label style={{...labelStyle, color: C.red}}>{t('wiz_lbl_dislikes')} 🚫</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 32, justifyContent: 'center' }}>
                {POPULAR_DISLIKES.map(item => {
                  const isSelected = form.dislikes.includes(item);
                  return (
                    <button
                      key={item} 
                      onClick={() => toggleArrayItem("dislikes", item)}
                      style={{
                        background: isSelected ? C.red : "rgba(0,0,0,0.3)", 
                        color: isSelected ? "#fff" : C.text,
                        border: `1px solid ${isSelected ? C.red : `${C.border}40`}`, 
                        padding: "10px 16px", borderRadius: 100, fontSize: 14, fontWeight: 700, cursor: "pointer", transition: "0.2s"
                      }}
                    >
                      {item} {isSelected && "❌"}
                    </button>
                  )
                })}
              </div>

              <label style={{...labelStyle, color: C.green}}>{t('wiz_lbl_likes')} ❤️</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 24, justifyContent: 'center' }}>
                {POPULAR_LIKES.map(item => {
                  const isSelected = form.likes.includes(item);
                  return (
                    <button
                      key={item} 
                      onClick={() => toggleArrayItem("likes", item)}
                      style={{
                        background: isSelected ? C.green : "rgba(0,0,0,0.3)", 
                        color: isSelected ? "#000" : C.text,
                        border: `1px solid ${isSelected ? C.green : `${C.border}40`}`, 
                        padding: "10px 16px", borderRadius: 100, fontSize: 14, fontWeight: 700, cursor: "pointer", transition: "0.2s"
                      }}
                    >
                      {item} {isSelected && "✅"}
                    </button>
                  )
                })}
              </div>
            </motion.div>
          )}

          {step === 8 && (
            <motion.div key="step8" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1, textAlign: "center" }}>
              <div style={{ fontSize: 64, marginBottom: 16, filter: `drop-shadow(0 0 20px ${C.blue}80)` }}>💧</div>
              <h2 style={{ margin: "0 0 12px 0", fontSize: 28, fontWeight: 900, fontFamily: fonts.header, color: C.blue }}>{t('wiz_step8_title')}</h2>
              <p style={{ margin: "0 0 32px 0", fontSize: 15, color: C.sub, lineHeight: 1.5, padding: "0 20px" }} dangerouslySetInnerHTML={{ __html: t('wiz_step8_desc') }} />
              
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "center", gap: 12, background: "rgba(0,0,0,0.3)", padding: 24, borderRadius: 24, border: `1px solid ${C.blue}40` }}>
                <input 
                  type="number" step="0.5" placeholder={t('wiz_ph_water')}
                  value={form.waterGoalLiters} 
                  onChange={e => setForm({...form, waterGoalLiters: e.target.value})} 
                  style={{ ...inputStyle, width: 140, marginBottom: 0, borderColor: C.blue, color: C.blue, fontSize: 32 }} 
                />
                <span style={{ fontSize: 20, fontWeight: 900, color: C.text, fontFamily: fonts.header }}>{t('wiz_unit_liter')}</span>
              </div>
            </motion.div>
          )}

        </AnimatePresence>

        <div style={{ display: "flex", gap: 16, marginTop: 40 }}>
          {step > 1 && (
            <button 
              onClick={() => setStep(step - 1)} 
              style={{ background: "rgba(0,0,0,0.3)", color: C.text, border: `1px solid ${C.border}60`, padding: "16px 24px", borderRadius: 20, fontWeight: 900, cursor: "pointer", fontFamily: fonts.header }}
            >
              {t('wiz_btn_back')}
            </button>
          )}
          <button 
            onClick={handleNext} 
            style={{ flex: 1, background: `linear-gradient(135deg, ${C.green}, #22c55e)`, color: "#000", border: "none", padding: "16px 24px", borderRadius: 20, fontWeight: 900, cursor: "pointer", fontSize: 16, fontFamily: fonts.header, boxShadow: `0 10px 30px ${C.green}40` }}
          >
            {step === totalSteps ? (t('wiz_btn_create') || "Planı Oluştur") : (t('wiz_btn_next') || "İleri")}
          </button>
        </div>
      </div>
    </div>
  );
}