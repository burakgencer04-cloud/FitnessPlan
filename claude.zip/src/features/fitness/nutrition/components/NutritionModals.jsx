import React, { useState, useMemo, useDeferredValue, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import BarcodeScannerComponent from "react-qr-barcode-scanner";
import { useTranslation } from 'react-i18next'; 

import { FOODS } from "@/features/fitness/nutrition/data/nutritionData";
import useModalStore from '@/shared/store/useModalStore'; 
import { fonts } from "@/features/fitness/nutrition/utils/nutritionUtils";
import AIVisionModal from "./AIVisionModal.jsx";

const STYLES = {
  overlay: { position: 'fixed', inset: 0, zIndex: 10000, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(10px)", display: 'flex', alignItems: 'center', justifyContent: 'center' },
  searchModal: (C) => ({ position: 'fixed', inset: 0, zIndex: 10000, background: `linear-gradient(145deg, ${C?.bg || '#000'}F2, ${C?.card || '#111'}F2)`, backdropFilter: "blur(24px)", display: 'flex', flexDirection: 'column', overflow: "hidden" })
};

export const getCategoryEmoji = (cat) => { /* ... önceki ile birebir aynı ... */ return "🍽️"; };
export const getPieceWeight = (name) => { /* ... önceki ile birebir aynı ... */ return 100; };

export function SearchFoodModal({ isOpen, onClose, onAddFood, onOpenDetails, onOpenScanner, customRecipes, targetMacros, plannedTotals, C }) {
   // ... [Adım 3'teki kodun BİREBİR aynısı (Güvenlik ağları zaten oradaydı)] ...
   if (!isOpen) return null;
   return (
    <motion.div initial={{ opacity: 0, y: "100%" }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: "100%" }} transition={{ type: "spring", damping: 28, stiffness: 250 }} style={STYLES.searchModal(C)}>
       {/* ... Render içeriği Adım 3 ile aynı ... */}
    </motion.div>
   );
}

// ... Diğer modallar (FoodDetailModal, BarcodeScannerModal, SamplePlanModal) önceki adımın aynısı olarak kalır ...

export default function NutritionModals({ logic, C = {}, t = (k) => k }) {
  if (!logic) return null;
  const { addItem, setAddItem, handleAddFood, selectedFoodDetails, setSelectedFoodDetails, showScanner, setShowScanner, showAIVision, setShowAIVision, showSamplePlan, setShowSamplePlan, customRecipes, targetMacros, plannedTotals, activePlan, handleApplySamplePlan, DAYS, nutDay } = logic;

  return (
    <AnimatePresence mode="wait">
      {!!addItem && <SearchFoodModal isOpen={!!addItem} onClose={() => setAddItem?.(null)} onAddFood={handleAddFood} onOpenDetails={setSelectedFoodDetails} onOpenScanner={() => setShowScanner?.(true)} customRecipes={customRecipes || []} targetMacros={targetMacros || {}} plannedTotals={plannedTotals || {}} C={C} />}
      {!!selectedFoodDetails && <FoodDetailModal food={selectedFoodDetails} onClose={() => setSelectedFoodDetails?.(null)} onAddFood={handleAddFood} C={C} />}
      {showScanner && <BarcodeScannerModal isOpen={showScanner ?? false} onClose={() => setShowScanner?.(false)} onProductFound={(food) => { setShowScanner?.(false); setSelectedFoodDetails?.(food); }} C={C} />}
      {showAIVision && <AIVisionModal isOpen={showAIVision ?? false} onClose={() => setShowAIVision?.(false)} onFoodDetected={(food) => handleAddFood?.(food, 1, false, false)} C={C} />}
      {showSamplePlan && <SamplePlanModal isOpen={showSamplePlan ?? false} onClose={() => setShowSamplePlan?.(false)} activePlan={activePlan || {}} onApplySamplePlan={handleApplySamplePlan} DAYS={DAYS} nutDay={nutDay ?? 0} C={C} />}
    </AnimatePresence>
  );
}