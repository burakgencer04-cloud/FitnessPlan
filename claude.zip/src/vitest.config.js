import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    }
  },
  // 🔥 EKLENDİ: Production'a çıkarken console ve debugger tamamen UÇURULACAK
  esbuild: {
    drop: ['console', 'debugger'], 
  },
  // 🔥 EKLENDİ: Vitest ayarlarımız
  test: {
    environment: 'jsdom', 
    globals: true, 
    server: { deps: { inline: [/C:/, /src\//] } },
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      exclude: ['node_modules/', 'src/test/', '**/*.config.js', 'src/shared/ui/'],
      thresholds: { lines: 80, functions: 80, branches: 80, statements: 80 }
    }
  },
  build: {
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('react') || id.includes('react-dom')) return 'vendor';
            if (id.includes('recharts')) return 'charts';
            if (id.includes('framer-motion')) return 'animations';
            if (id.includes('zustand')) return 'store';
          }
        }
      }
    }
  }
})