import { create } from 'zustand';

export const useModalStore = create((set) => ({
  isOpen: false,
  config: {
    type: 'alert', // 'alert' | 'confirm'
    title: 'Bilgi',
    message: '',
    confirmText: 'Tamam',
    cancelText: 'İptal',
    onConfirm: null,
  },
  
  openModal: (newConfig) => set({
    isOpen: true,
    config: {
      type: newConfig.type || 'alert',
      title: newConfig.title || 'Bilgi',
      message: newConfig.message || '',
      confirmText: newConfig.confirmText || 'Tamam',
      cancelText: newConfig.cancelText || 'İptal',
      onConfirm: newConfig.onConfirm || null,
    }
  }),
  
  closeModal: () => set((state) => ({ 
    isOpen: false, 
    // Kapanırken onConfirm callback'ini temizliyoruz ki hafızada asılı kalmasın
    config: { ...state.config, onConfirm: null } 
  }))
}));